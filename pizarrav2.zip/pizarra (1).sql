-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-11-2025 a las 06:01:17
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pizarra`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `id_registro` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `correo` varchar(180) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('presentador','invitado') NOT NULL DEFAULT 'invitado',
  `apodo` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`id_registro`, `nombre`, `correo`, `password`, `rol`, `apodo`, `created_at`, `updated_at`) VALUES
(1, 'Brayhan Hoyos', 'brayhan.hoyos@alumno.buap.mx', '$2y$10$S9s/yTdUDOJGNBuM3qsPVepBTDQ.4TZOpmOp5k.7wItTBwW08PYSO', 'invitado', 'invitado', '2025-10-30 00:47:31', NULL),
(2, 'Uriel Hoyos', 'uriel.hoyos@alumno.buap.mx', '$2y$10$QviOubLxSjBb1cB0PlxYQeIYZwsQnYnU5dnQnKLn.Hnl/GUwwQkwm', 'presentador', 'invitado', '2025-10-30 01:03:05', NULL),
(3, 'Pedrito Alcachofa', 'pedrito_alcachofa@gmail.com', '$2y$10$SAO.XtaXpknyyCGfHj17o./oxuJYvkM.e0jCsgf6KzoSAWAWsB6GK', 'invitado', 'invitado', '2025-10-30 04:46:31', NULL),
(4, 'Elizabeth Hernandez', 'elizabeth.hernandez@gmail.com', '$2y$10$dXkhxp0jHMPAbD2TZyHwWOLw6kLrLNgLCTvxiS5bAUAeFdP.nv44e', 'invitado', '\'invitado\'', '2025-11-27 15:40:32', NULL),
(5, 'Antonio Hoyos', 'antonio_hoyos@gmail.com', '$2y$10$8i0tdCGTuoZui4mXreJGnOiWtYCg0qC4.npMcFuDwoPR0Xl2LT7eS', 'invitado', '', '2025-11-27 15:42:09', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rooms`
--

CREATE TABLE `rooms` (
  `id_room` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(120) NOT NULL,
  `owner_user` varchar(180) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `closed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rooms`
--

INSERT INTO `rooms` (`id_room`, `code`, `name`, `owner_user`, `is_active`, `created_at`, `closed_at`) VALUES
(1, '41DA33', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-30 01:54:44', NULL),
(2, 'BD39CA', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 02:39:24', NULL),
(3, '526623', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 02:48:29', NULL),
(4, '662180', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 02:54:17', NULL),
(5, '136D2A', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 02:54:23', NULL),
(6, '56E3B0', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 03:16:03', NULL),
(7, '07A6D2', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 03:20:22', NULL),
(8, 'ADEEFC', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 03:35:01', NULL),
(9, 'DCB7E1', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 03:55:51', NULL),
(10, '28BAD7', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 03:58:28', NULL),
(11, 'F082C4', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 03:58:50', NULL),
(12, '51EC59', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 04:02:01', NULL),
(13, '461C33', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 04:03:08', NULL),
(14, '6D5C60', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 04:29:12', NULL),
(15, '4E78BD', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 04:41:02', NULL),
(16, '631F6E', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 05:01:44', NULL),
(17, '1875D9', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 05:03:52', NULL),
(18, 'EF6A62', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 05:05:19', NULL),
(19, 'D7BBAA', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-30 05:17:07', NULL),
(20, 'DB58EE', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-30 05:31:35', NULL),
(21, '7A628E', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 05:35:25', NULL),
(22, '8FBC0B', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 05:43:04', NULL),
(23, 'AE117A', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 05:44:54', NULL),
(24, '0FDDFE', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 05:46:05', NULL),
(25, 'F7F44A', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 06:12:08', NULL),
(26, '1EBFB8', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 06:28:51', NULL),
(27, '141039', 'Reunión rápida', 'pedrito_alcachofa@gmail.com', 1, '2025-10-30 06:38:53', NULL),
(28, '72BE13', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 17:17:24', NULL),
(29, '785583', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 17:18:17', NULL),
(30, '7E5A82', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-31 17:32:35', NULL),
(31, '2E2FAD', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-31 17:34:54', NULL),
(32, '937634', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-31 17:48:50', NULL),
(33, 'B6100F', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-31 17:49:03', NULL),
(34, 'DDF70C', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-31 18:11:58', NULL),
(35, '29E576', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:14:59', NULL),
(36, '6E791E', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:26:49', NULL),
(37, 'D4F28C', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:35:26', NULL),
(38, '2B6991', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:36:50', NULL),
(39, 'A559F3', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:37:25', NULL),
(40, '11D909', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:37:59', NULL),
(41, '64DE0F', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:39:26', NULL),
(42, '663F12', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 18:59:36', NULL),
(43, '5608E1', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 19:07:56', NULL),
(44, '0DD8B5', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 19:09:05', NULL),
(45, '92C584', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 19:09:34', NULL),
(46, '5B6313', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 19:12:10', NULL),
(47, '32843B', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-10-31 19:13:57', NULL),
(48, 'ED1696', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-10-31 19:29:01', NULL),
(49, 'F2DD54', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 14:24:04', NULL),
(50, '7BB4E1', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-11-27 15:16:40', NULL),
(51, 'AF05C6', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 15:17:04', NULL),
(52, 'E9EFAF', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 15:55:06', NULL),
(53, '33F09F', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 16:17:46', NULL),
(54, '922BEF', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 16:21:01', NULL),
(55, '0ADC8F', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 16:44:36', NULL),
(56, 'C761AB', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 16:54:11', NULL),
(57, 'E5EBE8', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 16:54:40', NULL),
(58, '5C92C5', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 16:58:56', NULL),
(59, '7F63DE', 'Reunión rápida', 'brayhan.hoyos@alumno.buap.mx', 1, '2025-11-27 16:59:26', NULL),
(60, '0E8216', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 17:33:44', NULL),
(61, '52A875', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 20:53:35', NULL),
(62, '4D21B0', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 21:06:11', NULL),
(63, '35C4EF', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 21:21:28', NULL),
(64, '1D25BE', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 21:48:08', NULL),
(65, '96E2DC', 'Reunión rápida', 'uriel.hoyos@alumno.buap.mx', 1, '2025-11-27 22:43:37', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `room_members`
--

CREATE TABLE `room_members` (
  `id` bigint(20) NOT NULL,
  `room_id` int(11) NOT NULL,
  `correo` varchar(180) NOT NULL,
  `role_in_room` enum('presentador','invitado') NOT NULL DEFAULT 'invitado',
  `joined_at` datetime NOT NULL DEFAULT current_timestamp(),
  `left_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `room_messages`
--

CREATE TABLE `room_messages` (
  `id` bigint(20) NOT NULL,
  `room_id` int(11) NOT NULL,
  `correo` varchar(180) NOT NULL,
  `message` text NOT NULL,
  `sent_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `rol` varchar(50) NOT NULL,
  `correo` varchar(180) NOT NULL,
  `fecha_uso` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `rol`, `correo`, `fecha_uso`) VALUES
(1, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-30 01:41:36'),
(2, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 02:30:52'),
(3, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-30 02:53:27'),
(4, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 02:54:13'),
(5, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 03:15:57'),
(6, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 03:34:55'),
(7, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 03:55:46'),
(8, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 04:01:56'),
(9, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 04:29:07'),
(10, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-30 04:30:04'),
(11, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 04:40:59'),
(12, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-30 04:41:12'),
(13, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-30 04:46:49'),
(14, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 05:03:48'),
(15, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-30 05:05:18'),
(16, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-30 05:17:33'),
(17, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-30 05:28:17'),
(18, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-30 05:32:13'),
(19, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-30 06:54:55'),
(20, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 17:17:20'),
(21, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-31 17:30:33'),
(22, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-31 17:35:36'),
(23, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 18:14:44'),
(24, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 18:14:58'),
(25, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-31 18:55:08'),
(26, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-31 18:55:43'),
(27, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 18:56:12'),
(28, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-31 18:56:53'),
(29, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 18:57:19'),
(30, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-31 18:58:00'),
(31, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 18:58:47'),
(32, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 18:59:21'),
(33, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 19:11:22'),
(34, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-31 19:12:33'),
(35, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-10-31 19:17:27'),
(36, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-10-31 19:18:29'),
(37, 'Pedrito Alcachofa', 'invitado', 'pedrito_alcachofa@gmail.com', '2025-10-31 19:31:19'),
(38, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 14:23:51'),
(39, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-11-27 14:24:16'),
(40, 'Antonio Hoyos', 'invitado', 'antonio_hoyos@gmail.com', '2025-11-27 15:42:30'),
(41, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 15:54:55'),
(42, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-11-27 15:57:37'),
(43, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 20:53:28'),
(44, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-11-27 20:54:24'),
(45, 'Antonio Hoyos', 'invitado', 'antonio_hoyos@gmail.com', '2025-11-27 20:57:37'),
(46, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 21:06:10'),
(47, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-11-27 21:07:26'),
(48, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 21:21:26'),
(49, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 21:48:07'),
(50, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-11-27 21:50:12'),
(51, 'Brayhan Hoyos', 'invitado', 'brayhan.hoyos@alumno.buap.mx', '2025-11-27 21:53:05'),
(52, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 22:43:34'),
(53, 'Antonio Hoyos', 'invitado', 'antonio_hoyos@gmail.com', '2025-11-27 22:45:10'),
(54, 'Uriel Hoyos', 'presentador', 'uriel.hoyos@alumno.buap.mx', '2025-11-27 22:45:48'),
(55, 'Antonio Hoyos', 'invitado', 'antonio_hoyos@gmail.com', '2025-11-27 22:51:01');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id_registro`),
  ADD UNIQUE KEY `uk_registro_correo` (`correo`);

--
-- Indices de la tabla `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id_room`),
  ADD UNIQUE KEY `uk_rooms_code` (`code`),
  ADD KEY `idx_rooms_owner` (`owner_user`);

--
-- Indices de la tabla `room_members`
--
ALTER TABLE `room_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_room_members_room` (`room_id`),
  ADD KEY `idx_room_members_user` (`correo`);

--
-- Indices de la tabla `room_messages`
--
ALTER TABLE `room_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_msg_room` (`room_id`),
  ADD KEY `idx_msg_user` (`correo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuarios_correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `registro`
--
ALTER TABLE `registro`
  MODIFY `id_registro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT de la tabla `room_members`
--
ALTER TABLE `room_members`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `room_messages`
--
ALTER TABLE `room_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `fk_rooms_owner` FOREIGN KEY (`owner_user`) REFERENCES `registro` (`correo`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `room_members`
--
ALTER TABLE `room_members`
  ADD CONSTRAINT `fk_rm_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id_room`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rm_user` FOREIGN KEY (`correo`) REFERENCES `registro` (`correo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `room_messages`
--
ALTER TABLE `room_messages`
  ADD CONSTRAINT `fk_msg_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id_room`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_msg_user` FOREIGN KEY (`correo`) REFERENCES `registro` (`correo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
