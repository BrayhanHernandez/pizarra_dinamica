<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: login.php"); exit(); }

$code = isset($_GET['code']) ? htmlspecialchars($_GET['code']) : 'N/A';
$user = $_SESSION['usuario'];
$apodo = isset($_GET['apodo']) ? htmlspecialchars($_GET['apodo']) : '';

/* ===== Funciones para iniciales y color determinístico ===== */
function __initials($s){
  $s = trim($s);
  if (strpos($s, '@') !== false) $s = substr($s, 0, strpos($s, '@'));
  $parts = preg_split('/[\s._-]+/u', $s, -1, PREG_SPLIT_NO_EMPTY);
  $ini = '';
  foreach ($parts as $p) {
    $ini .= mb_strtoupper(mb_substr($p, 0, 1, 'UTF-8'), 'UTF-8');
    if (mb_strlen($ini, 'UTF-8') >= 2) break;
  }
  return $ini ?: 'U';
}

function __hsl_from_string($s) {
  $h = crc32($s) % 360;  // tono estable 0..359
  $satu = 70;            // saturación %
  $light = 42;           // luminosidad %
  return [$h, $satu, $light];
}

function __avatar_style($nameOrEmail) {
  [$h,$s,$l] = __hsl_from_string($nameOrEmail);
  $lBorder = max(0, $l - 8);
  $bg = "hsl($h {$s}% {$l}%)";
  $bd = "hsl($h {$s}% {$lBorder}%)";
  $txt = ($l >= 60) ? '#111' : '#fff';
  return "background:$bg;color:$txt;border:2px solid $bd;";
}

/* ===== Datos para el avatar con iniciales ===== */
$__displayName = $_SESSION['nombre'] ?? $_SESSION['usuario'] ?? 'Usuario';
$__initials    = __initials($__displayName);
$__style       = __avatar_style($__displayName);

// (opcional) guarda en sesión para reusar en otras páginas
$_SESSION['avatar_color'] = $__style;
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Sala de reunión: <?php echo $code; ?></title>
  <link rel="stylesheet" href="css/styles_room.css"/>
</head>
<body>
  <header class="topbar">
    <div class="left">Sala de reunión: <strong><?php echo $code; ?></strong></div>
    <div class="right">
      <button id="btnChatToggle" class="chip" title="Chat">💬</button>
      <button id="btnLeaveTop" class="btn btn--dark" title="Cerrar sesión">Cerrar sesión</button>
    <div class="avatar small"
         title="<?php echo htmlspecialchars($user); ?>"
         style="<?php echo $__style; ?>">
      <span class="avatar__text"><?php echo htmlspecialchars($__initials); ?></span>
    </div>
    </div>
  </header>

  <main class="shell">
    <aside class="rail">
      <div class="rail-head">
        <div class="ttl">Participantes</div>
      </div>

      <div id="railTiles" class="thumbs">
        <article class="thumb" data-peer="local">
          <div class="video-wrap">
            <video id="vLocal" autoplay playsinline muted></video>
            <div class="badges">
              <span class="badge badge--mic" hidden>🔇</span>
              <span class="badge badge--hand" hidden>✋</span>
            </div>
          </div>
          <div class="meta">
            <div class="name"><?php echo htmlspecialchars($user); ?></div>
            <div class="apodo">APODO: <?php echo ($apodo ?: '—'); ?></div>
          </div>
        </article>
        </div>

      <div class="chat">
        <div class="chat__title">CHAT</div>
        <div id="chatStream" class="chat__stream"></div>
        <form id="chatForm" class="chat__form" autocomplete="off">
          <button type="button" class="chat__menu">≡</button>
          <input id="chatInput" class="chat__input" placeholder="Escribe un mensaje…"/>
          <button class="chat__send" title="Enviar">➤</button>
        </form>
      </div>
    </aside>

    <section class="stage">
      <div class="board" id="board">
        <canvas id="boardCanvas"></canvas>
        <div class="board__placeholder">Pizarra colaborativa</div>
      </div>

      <div class="dock">
        <button class="tool" id="tSelect" title="Seleccionar">🖱️</button>
        <button class="tool" id="tPen" title="Lápiz">✏️</button>
        <button class="tool" id="tRect" title="Rectángulo">▭</button>
        <button class="tool" id="tText" title="Texto">Tt</button>
        <button class="tool" id="tClear" title="Limpiar pizarra">🗑️</button>
        <div class="sp"></div>
        <button class="round" id="btnMic" data-on="1" title="Micrófono">🎤</button>
        <button class="round" id="btnCam" data-on="1" title="Cámara">📷</button>
        <button class="round" id="btnHand" data-on="0" title="Levantar mano">✋</button>
        <button class="round" id="btnShare" title="Compartir pantalla">🖥️</button>
        <button class="round round--record" id="btnRecord" data-state="off" title="Grabar">⏺</button>
        <button class="round round--danger" id="btnLeave" title="Salir">⛔</button>
        <select id="selMic" class="sel" title="Micrófono"></select>
        <select id="selCam" class="sel" title="Cámara"></select>
        <span id="webrtcStatus" class="status">Conectando…</span>
      </div>
    </section>
  </main>

<script>
    window.WEBRTC_CONFIG = {
      ROOM_ID: "<?php echo $code; ?>",
      USER_ID: "<?php echo htmlspecialchars($user); ?>",
      WS_URL: "ws://localhost:8081",
      ICE_SERVERS: [{ urls: 'stun:stun.l.google.com:19302' }]
    };
  </script>

  <script type="module">
    // Importamos WEBRTC. Si falla aquí, revisa js/webrtc-core.js
    import { WEBRTC } from './js/webrtc-core.js';

    const rail = document.getElementById('railTiles');
    const vLocal = document.getElementById('vLocal');

    // Usamos el objeto importado directamente
    if (WEBRTC) {
        // Evento: Me uní
        WEBRTC.on.joined = () => {
          if (WEBRTC.state.localStream && vLocal) {
             vLocal.srcObject = WEBRTC.state.localStream;
             // Quitar el silencio local para evitar feedback, o dejar muted
             vLocal.muted = true; 
          }
        };

        // Función auxiliar para crear tiles
        function ensureRemoteTile(peerId, stream) {
          let tile = rail.querySelector(`article.thumb[data-peer="${peerId}"]`);
          if (!tile) {
            tile = document.createElement('article');
            tile.className = 'thumb';
            tile.dataset.peer = peerId;
            tile.innerHTML = `
              <div class="video-wrap">
                <video autoplay playsinline></video>
                <div class="badges">
                  <span class="badge badge--mic" hidden>🔇</span>
                  <span class="badge badge--hand" hidden>✋</span>
                </div>
              </div>
              <div class="meta">
                <div class="name">${peerId}</div>
                <div class="apodo">APODO: —</div>
              </div>`;
            rail.appendChild(tile);
          }
          const v = tile.querySelector('video');
          if (v && v.srcObject !== stream) v.srcObject = stream;
        }

        // Eventos del Core
        WEBRTC.on.remoteStream = (peerId, stream) => ensureRemoteTile(peerId, stream);
        WEBRTC.on.peerLeft = (peerId) => rail.querySelector(`article.thumb[data-peer="${peerId}"]`)?.remove();
        WEBRTC.on.ws = (s) => { const el = document.getElementById('webrtcStatus'); if (el) el.textContent = s; };

        // Iniciar conexión
        WEBRTC.connect();
    }
  </script>

  <script defer src="js/room.js"></script>
</body>
</html>