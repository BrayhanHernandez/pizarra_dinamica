// js/webrtc-core.js (ESM)
const WEBRTC = {
  cfg: null,
  ws: null,
  state: {
    localStream: null,
    screenStream: null,
    peers: new Map(),
  },
  on: {
    ws: (st)=>{},
    joined: ()=>{},
    remoteStream: (peerId, stream)=>{},
    peerLeft: (peerId)=>{},
    custom: (msg)=>{},
  }
};

window.WEBRTC = WEBRTC; // Para compatibilidad global

function log(...a){ console.log('[WEBRTC]', ...a); }
function sendWS(o){ try{ WEBRTC.ws?.send(JSON.stringify(o)); }catch{} }

WEBRTC.connect = async function(){
  WEBRTC.cfg = window.WEBRTC_CONFIG;
  const { ROOM_ID, WS_URL } = WEBRTC.cfg;

  try {
    WEBRTC.state.localStream = await navigator.mediaDevices.getUserMedia({ audio:true, video:true });
  } catch (e) {
    console.warn('Sin acceso a media, iniciando modo solo recepción.');
    WEBRTC.state.localStream = new MediaStream();
  }

  const ws = new WebSocket(WS_URL);
  WEBRTC.ws = ws;

  ws.onopen = () => {
    WEBRTC.on.ws('Conectado');
    sendWS({ type:'join', roomId: ROOM_ID });
  };
  ws.onclose = () => WEBRTC.on.ws('Desconectado');

  ws.onmessage = async (ev) => {
    let msg; try { msg = JSON.parse(ev.data); } catch { return; }

    if (msg.type === 'peers') {
      for (const peerId of msg.peers || []) {
        ensurePeer(peerId, true); // true = polite (somos los nuevos)
      }
      WEBRTC.on.joined();
      return;
    }

    if (msg.type === 'peer-joined') {
      ensurePeer(msg.peerId, false); // false = impolite (nosotros mandamos)
      return;
    }

    // js/webrtc-core.js (Cambiando el manejador de 'offer')

    if (msg.type === 'offer') {
      const info = ensurePeer(msg.from, true); 
      const pc = info.pc;
      
      // Lógica de colisión
      const offerCollision = (info.makingOffer || pc.signalingState !== 'stable');
      info.ignoreOffer = !info.polite && offerCollision;

      if (info.ignoreOffer) return; // Ignoramos si somos impolite y colisionamos

      try {
        // 1. Manejar el Rollback si hubo colisión y NO estamos en stable
        if (offerCollision && pc.signalingState !== 'stable') {
            await pc.setLocalDescription({ type: 'rollback' }); 
        } 
        // 2. Aplicar la oferta remota
        await pc.setRemoteDescription(msg.sdp);
        
        // 3. Crear y enviar la respuesta
        const ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        
        sendWS({ type:'answer', to: msg.from, sdp: pc.localDescription });
        flushPendingIce(info);
      } catch (e) {
        // En caso de error, el error de InvalidState ahora será capturado aquí
        console.error('Error handling offer:', e);
      }
      return;
    }

    if (msg.type === 'answer') {
      const info = WEBRTC.state.peers.get(msg.from);
      if (!info) return;
      try {
        if (info.pc.signalingState === 'have-local-offer') {
          await info.pc.setRemoteDescription(msg.sdp);
          flushPendingIce(info);
        }
      } catch (e) {}
      return;
    }

    if (msg.type === 'ice') {
      const info = WEBRTC.state.peers.get(msg.from);
      if (!info) return;
      if (!info.pc.remoteDescription) info.pendingCandidates.push(msg.candidate);
      else try { if(msg.candidate) await info.pc.addIceCandidate(msg.candidate); } catch(e){}
      return;
    }

    if (msg.type === 'peer-left') {
      WEBRTC.state.peers.get(msg.peerId)?.pc?.close();
      WEBRTC.state.peers.delete(msg.peerId);
      WEBRTC.on.peerLeft(msg.peerId);
      return;
    }

    if (msg.type === 'custom' || msg.data?.type) WEBRTC.on.custom(msg);
  };
};

/* --- Helpers --- */
function ensurePeer(peerId, polite){
  let info = WEBRTC.state.peers.get(peerId);
  if (info) return info;

  const pc = new RTCPeerConnection({ iceServers: WEBRTC.cfg.ICE_SERVERS });
  info = { pc, stream: new MediaStream(), polite, makingOffer: false, ignoreOffer: false, pendingCandidates: [] };
  WEBRTC.state.peers.set(peerId, info);

  const tracks = WEBRTC.state.localStream.getTracks();
  if (tracks.length > 0) tracks.forEach(t => pc.addTrack(t, WEBRTC.state.localStream));
  else {
    pc.addTransceiver('audio', { direction: 'recvonly' });
    pc.addTransceiver('video', { direction: 'recvonly' });
  }

  pc.onnegotiationneeded = async () => {
    try {
      info.makingOffer = true;
      await pc.setLocalDescription();
      sendWS({ type:'offer', to: peerId, sdp: pc.localDescription });
    } catch(e) { console.warn(e); } 
    finally { info.makingOffer = false; }
  };

  pc.onicecandidate = ({candidate}) => candidate && sendWS({ type:'ice', to: peerId, candidate });
  pc.ontrack = (e) => {
    e.streams[0].getTracks().forEach(t => info.stream.addTrack(t));
    WEBRTC.on.remoteStream(peerId, info.stream);
  };
  return info;
}

function flushPendingIce(info){
  if (!info.pc.remoteDescription) return;
  const c = info.pendingCandidates.splice(0);
  c.forEach(x => { if(x) info.pc.addIceCandidate(x).catch(()=>{}); });
}

// APIs adicionales
WEBRTC.listDevices = async () => {
  const d = await navigator.mediaDevices.enumerateDevices();
  return { mics: d.filter(x=>x.kind=='audioinput'), cams: d.filter(x=>x.kind=='videoinput') };
};
WEBRTC.setMic = async (id) => {}; // Lógica simplificada para brevedad, usa la tuya si la tienes
WEBRTC.setCam = async (id) => {}; 
WEBRTC.startScreenShare = async () => {};
WEBRTC.stopScreenShare = async () => {};
WEBRTC.sendCustom = (type, payload) => {
  sendWS({ type:'custom', roomId: WEBRTC.cfg.ROOM_ID, userId: WEBRTC.cfg.USER_ID, data: { type, ...payload } });
};
WEBRTC.leave = () => {
  WEBRTC.ws?.close();
  WEBRTC.state.localStream?.getTracks().forEach(t=>t.stop());
  WEBRTC.state.peers.forEach(p => p.pc.close());
  WEBRTC.state.peers.clear();
};

// --- IMPORTANTE: ESTA LÍNEA ES LA QUE TE FALTA ---
export { WEBRTC };