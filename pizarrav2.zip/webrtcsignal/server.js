// server.js — señalización WebRTC mínima con heartbeat
const { WebSocketServer } = require('ws');

const PORT = 8081;
const wss = new WebSocketServer({ port: PORT });
const rooms = new Map(); // roomId -> Set<WebSocket>

function send(ws, obj) { try { ws.send(JSON.stringify(obj)); } catch {} }
function broadcast(roomId, obj, except) {
  const set = rooms.get(roomId);
  if (!set) return;
  for (const cli of set) {
    if (cli !== except && cli.readyState === 1) send(cli, obj);
  }
}

wss.on('listening', () => {
  console.log(`WS signaling on ws://localhost:${PORT}`);
});

// Heartbeat para limpiar sockets colgados
function heartbeat() { this.isAlive = true; }
wss.on('connection', (ws) => {
  console.log('Cliente conectado');
  ws.isAlive = true;
  ws.on('pong', heartbeat);

  ws.roomId = null;
  ws.id = null;

  ws.on('message', (raw) => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    const { type } = msg;

    if (type === 'join') {
      ws.roomId = msg.roomId;
      if (!rooms.has(ws.roomId)) rooms.set(ws.roomId, new Set());
      const set = rooms.get(ws.roomId);

      ws.id = Math.random().toString(36).slice(2, 8);

      // peers existentes al que entra
      send(ws, { type: 'peers', peers: [...set].map(x => x.id).filter(Boolean) });

      set.add(ws);
      console.log(`JOIN room=${ws.roomId} peer=${ws.id}`);
      broadcast(ws.roomId, { type: 'peer-joined', peerId: ws.id }, ws);
      return;
    }

    if (type === 'offer' || type === 'answer' || type === 'ice') {
      const set = rooms.get(msg.roomId || ws.roomId);
      if (!set) return;
      const to = [...set].find(x => x.id && x.id === msg.to);
      if (to) {
        // reenviar con from correcto
        send(to, { type, from: ws.id, sdp: msg.sdp, candidate: msg.candidate });
      }
      return;
    }

    // Canal genérico para chat/hand/board/etc.
    if (type === 'custom') {
      const data = msg.data || msg.payload || {};
      broadcast(msg.roomId || ws.roomId, { type: 'custom', from: ws.id, data }, ws);
      return;
    }

    // Compatibilidad con mensajes directos antiguos
    if (type === 'chat' || type === 'hand' || type === 'mute-ind') {
      broadcast(msg.roomId || ws.roomId, { type, from: ws.id, ...msg }, ws);
    }
  });

  ws.on('close', () => {
    const rid = ws.roomId;
    console.log('Cliente salió', rid ? `(room ${rid})` : '');
    const set = rid ? rooms.get(rid) : null;
    if (set) {
      set.delete(ws);
      broadcast(rid, { type: 'peer-left', peerId: ws.id }, ws);
      if (set.size === 0) rooms.delete(rid);
    }
  });
});

// barrido de conexiones muertas
const interval = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) return ws.terminate();
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  });
}, 30000);

wss.on('close', () => clearInterval(interval));
wss.on('error', (err) => console.error('WS error:', err));



